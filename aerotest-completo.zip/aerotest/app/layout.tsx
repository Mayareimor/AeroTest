import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AeroTest — Test Kit para estudiantes de aviación",
  description:
    "Plataforma de práctica de exámenes para estudiantes de aviación: banco de preguntas, exámenes aleatorios y estadísticas de progreso.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body className="font-body">{children}</body>
    </html>
  );
}
