export default function Home() {
  return (
    <main className="min-h-screen bg-navy text-cloud">
      <nav className="flex items-center justify-between max-w-6xl mx-auto px-6 py-6">
        <div className="flex items-center gap-2 font-display font-semibold text-lg">
          <div className="w-9 h-9 rounded-lg bg-accent flex items-center justify-center text-white font-bold">
            A
          </div>
          AERO<span className="text-accent">TEST</span>
        </div>
        <div className="hidden md:flex gap-8 text-sm text-cloud-dim">
          <a href="#plataforma">Plataforma</a>
          <a href="#modos">Modos de estudio</a>
        </div>
        <div className="flex gap-3">
          <button className="text-sm font-medium px-4 py-2 border border-steel-light rounded-lg">
            Iniciar sesión
          </button>
          <button className="text-sm font-semibold px-4 py-2 rounded-lg bg-accent text-white">
            Registrarse
          </button>
        </div>
      </nav>

      <section className="max-w-6xl mx-auto px-6 pt-10 pb-24">
        <span className="inline-block text-xs font-mono font-semibold tracking-widest text-accent bg-accent/10 px-3 py-1 rounded-full">
          PREPARACIÓN DE VUELO · TEST KIT
        </span>
        <h1 className="mt-6 text-4xl md:text-5xl font-display font-bold leading-tight max-w-2xl">
          Vuela hacia tu examen con instrumentos de verdad.
        </h1>
        <p className="mt-5 text-cloud-dim max-w-xl leading-relaxed">
          AeroTest es tu banco de preguntas y simulador de exámenes para
          estudiantes de aviación. Practica con exámenes aleatorios de 50
          preguntas, mide tu progreso por materia y llega a tu evaluación
          real con la confianza de un piloto que ya voló la ruta.
        </p>
        <div className="mt-8 flex gap-4">
          <button className="px-6 py-3 rounded-lg font-semibold text-sm bg-accent text-white">
            Comenzar examen de práctica
          </button>
          <button className="px-6 py-3 rounded-lg font-semibold text-sm border border-steel-light">
            Ver demo
          </button>
        </div>
      </section>

      <section id="plataforma" className="max-w-6xl mx-auto px-6 py-16">
        <h2 className="text-2xl font-display font-bold">
          Panel de instrumentos del estudiante
        </h2>
        <p className="text-slate text-sm mt-2">
          Todo lo que necesitas para preparar tu evaluación, en un solo
          lugar.
        </p>
        <div className="grid md:grid-cols-3 gap-5 mt-8">
          {[
            {
              code: "01 · DASHBOARD",
              title: "Progreso en tiempo real",
              desc: "Promedio, tiempo estudiado, exámenes realizados y estadísticas por materia y tema.",
            },
            {
              code: "02 · EXAMEN",
              title: "Simulador de examen oficial",
              desc: "50 preguntas aleatorias, opciones mezcladas, temporizador y resultados detallados.",
            },
            {
              code: "03 · BANCO",
              title: "Miles de preguntas",
              desc: "Estructura lista para materia, tema, dificultad, etiquetas e imagen.",
            },
          ].map((f) => (
            <div
              key={f.code}
              className="bg-steel border border-steel-light rounded-2xl p-6"
            >
              <span className="font-mono text-xs font-bold text-accent">
                {f.code}
              </span>
              <h3 className="mt-3 font-display font-semibold text-lg">
                {f.title}
              </h3>
              <p className="mt-2 text-sm text-cloud-dim leading-relaxed">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section id="modos" className="max-w-6xl mx-auto px-6 py-16">
        <h2 className="text-2xl font-display font-bold">
          Elige tu ruta de estudio
        </h2>
        <div className="mt-8">
          {[
            ["Examen oficial", "50 preguntas · cronometrado"],
            ["Práctica libre", "sin límite de tiempo"],
            ["Solo incorrectas", "refuerza tus fallos"],
            ["Favoritas", "tu selección personal"],
            ["Por materia", "enfoque temático"],
            ["Por tema", "precisión quirúrgica"],
          ].map(([label, detail]) => (
            <div
              key={label}
              className="flex justify-between py-4 border-b border-steel-light text-sm"
            >
              <span className="font-medium">{label}</span>
              <span className="text-slate">{detail}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-14 border-t border-steel-light flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-xl font-display font-bold">
            Prepárate para despegar.
          </h3>
          <p className="text-slate text-sm mt-1">
            Crea tu cuenta y empieza tu primer examen de práctica.
          </p>
        </div>
        <button className="px-6 py-3 rounded-lg font-semibold text-sm bg-accent text-white">
          Crear cuenta gratis
        </button>
      </section>
    </main>
  );
}
