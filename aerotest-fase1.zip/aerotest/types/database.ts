export type Difficulty = "easy" | "medium" | "hard";

export type ExamMode =
  | "official"
  | "free_practice"
  | "incorrect_only"
  | "favorites"
  | "by_subject"
  | "by_topic";

export interface Subject {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  sort_order: number;
}

export interface Topic {
  id: string;
  subject_id: string;
  name: string;
  slug: string;
  sort_order: number;
}

export interface QuestionOption {
  id: string;
  question_id: string;
  option_text: string;
  is_correct: boolean;
  sort_order: number;
}

export interface Question {
  id: string;
  subject_id: string;
  topic_id: string | null;
  question_text: string;
  image_url: string | null;
  explanation: string | null;
  difficulty: Difficulty;
  tags: string[];
  is_active: boolean;
  options?: QuestionOption[];
}

export interface Exam {
  id: string;
  student_id: string;
  mode: ExamMode;
  subject_id: string | null;
  topic_id: string | null;
  total_questions: number;
  time_limit_seconds: number | null;
  status: "in_progress" | "completed" | "abandoned";
  score: number | null;
  correct_count: number | null;
  incorrect_count: number | null;
  time_used_seconds: number | null;
  started_at: string;
  finished_at: string | null;
}

export interface ExamQuestion {
  id: string;
  exam_id: string;
  question_id: string;
  position: number;
  shuffled_option_ids: string[];
  selected_option_id: string | null;
  is_correct: boolean | null;
  is_flagged: boolean;
  answered_at: string | null;
}

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  role: "student" | "admin";
  study_streak_days: number;
  last_study_date: string | null;
}
