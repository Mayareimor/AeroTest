-- ============================================================
-- AEROTEST — ESQUEMA DE BASE DE DATOS (Supabase / Postgres)
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- PERFILES (extiende auth.users) ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  role text not null default 'student' check (role in ('student', 'admin')),
  study_streak_days int not null default 0,
  last_study_date date,
  created_at timestamptz not null default now()
);

-- ---------- MATERIAS Y TEMAS ----------
create table public.subjects (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  slug text not null unique,
  icon text,
  sort_order int not null default 0
);

create table public.topics (
  id uuid primary key default uuid_generate_v4(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  name text not null,
  slug text not null,
  sort_order int not null default 0,
  unique (subject_id, slug)
);

-- ---------- BANCO DE PREGUNTAS ----------
create table public.questions (
  id uuid primary key default uuid_generate_v4(),
  subject_id uuid not null references public.subjects(id),
  topic_id uuid references public.topics(id),
  question_text text not null,
  image_url text,
  explanation text,
  difficulty text not null default 'medium' check (difficulty in ('easy', 'medium', 'hard')),
  tags text[] not null default '{}',
  is_active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 3 respuestas + 1 correcta (tabla separada para poder mezclar el orden)
create table public.question_options (
  id uuid primary key default uuid_generate_v4(),
  question_id uuid not null references public.questions(id) on delete cascade,
  option_text text not null,
  is_correct boolean not null default false,
  sort_order int not null default 0
);

create index idx_questions_subject on public.questions(subject_id);
create index idx_questions_topic on public.questions(topic_id);
create index idx_questions_tags on public.questions using gin(tags);
create index idx_options_question on public.question_options(question_id);

-- ---------- EXÁMENES ----------
create table public.exams (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  mode text not null check (mode in (
    'official', 'free_practice', 'incorrect_only', 'favorites', 'by_subject', 'by_topic'
  )),
  subject_id uuid references public.subjects(id),
  topic_id uuid references public.topics(id),
  total_questions int not null default 50,
  time_limit_seconds int,
  status text not null default 'in_progress' check (status in ('in_progress', 'completed', 'abandoned')),
  score numeric(5,2),
  correct_count int,
  incorrect_count int,
  time_used_seconds int,
  started_at timestamptz not null default now(),
  finished_at timestamptz
);

-- Instantánea de cada pregunta dentro de un examen concreto
-- (guarda el orden y las opciones ya mezcladas para ese intento)
create table public.exam_questions (
  id uuid primary key default uuid_generate_v4(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id uuid not null references public.questions(id),
  position int not null,
  shuffled_option_ids uuid[] not null,
  selected_option_id uuid,
  is_correct boolean,
  is_flagged boolean not null default false,
  answered_at timestamptz
);

create index idx_exam_questions_exam on public.exam_questions(exam_id);

-- ---------- FAVORITOS ----------
create table public.favorite_questions (
  student_id uuid not null references public.profiles(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (student_id, question_id)
);

-- ---------- INSIGNIAS / RACHAS / RANKING ----------
create table public.badges (
  id uuid primary key default uuid_generate_v4(),
  code text not null unique,
  name text not null,
  description text,
  icon text
);

create table public.student_badges (
  student_id uuid not null references public.profiles(id) on delete cascade,
  badge_id uuid not null references public.badges(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key (student_id, badge_id)
);

-- Vista de ranking (promedio + exámenes completados)
create view public.leaderboard as
select
  p.id as student_id,
  p.full_name,
  count(e.id) filter (where e.status = 'completed') as exams_completed,
  round(avg(e.score) filter (where e.status = 'completed'), 2) as avg_score,
  p.study_streak_days
from public.profiles p
left join public.exams e on e.student_id = p.id
group by p.id;

-- ---------- ROW LEVEL SECURITY ----------
alter table public.profiles enable row level security;
alter table public.exams enable row level security;
alter table public.exam_questions enable row level security;
alter table public.favorite_questions enable row level security;
alter table public.questions enable row level security;
alter table public.question_options enable row level security;

-- Perfiles: cada quien ve y edita el suyo; los admins ven todos
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id or exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'
));
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- Preguntas: lectura para todos los autenticados, escritura solo admin
create policy "questions_read_all" on public.questions for select using (auth.role() = 'authenticated');
create policy "questions_admin_write" on public.questions for all using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy "options_read_all" on public.question_options for select using (auth.role() = 'authenticated');
create policy "options_admin_write" on public.question_options for all using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);

-- Exámenes: cada estudiante ve y crea solo los suyos
create policy "exams_own" on public.exams for all using (auth.uid() = student_id);
create policy "exam_questions_own" on public.exam_questions for all using (
  exists (select 1 from public.exams e where e.id = exam_id and e.student_id = auth.uid())
);
create policy "favorites_own" on public.favorite_questions for all using (auth.uid() = student_id);

-- ---------- TRIGGER: crear perfil automáticamente al registrarse ----------
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
