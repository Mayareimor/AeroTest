import { NextRequest, NextResponse } from "next/server";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import { createClient } from "@/lib/supabase/server";

/**
 * Formato esperado del archivo (CSV o XLSX), una fila por pregunta:
 *
 * subject | topic | question | image_url | option_1 | option_2 | option_3 |
 * correct_option (1, 2 o 3) | explanation | difficulty | tags (separadas por ;)
 *
 * Este endpoint es solo para administradores (verificado por RLS + rol).
 */
export async function POST(req: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user?.id)
    .single();

  if (!user || profile?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado." }, { status: 403 });
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  if (!file) {
    return NextResponse.json({ error: "No se envió ningún archivo." }, { status: 400 });
  }

  const rows = await parseFile(file);
  const results = { inserted: 0, failed: [] as { row: number; reason: string }[] };

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    try {
      await insertQuestionRow(supabase, row, user.id);
      results.inserted++;
    } catch (err: any) {
      results.failed.push({ row: i + 2, reason: err.message }); // +2: fila 1 es encabezado
    }
  }

  return NextResponse.json(results, { status: 200 });
}

async function parseFile(file: File): Promise<any[]> {
  const name = file.name.toLowerCase();

  if (name.endsWith(".csv")) {
    const text = await file.text();
    const { data } = Papa.parse(text, { header: true, skipEmptyLines: true });
    return data as any[];
  }

  // .xlsx / .xls
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json(sheet);
}

async function insertQuestionRow(supabase: ReturnType<typeof createClient>, row: any, adminId: string) {
  const requiredFields = ["subject", "question", "option_1", "option_2", "option_3", "correct_option"];
  for (const field of requiredFields) {
    if (!row[field]) throw new Error(`Falta la columna "${field}".`);
  }

  const { data: subject } = await supabase
    .from("subjects")
    .select("id")
    .eq("name", row.subject)
    .single();
  if (!subject) throw new Error(`Materia "${row.subject}" no existe.`);

  let topicId: string | null = null;
  if (row.topic) {
    const { data: topic } = await supabase
      .from("topics")
      .select("id")
      .eq("subject_id", subject.id)
      .eq("name", row.topic)
      .single();
    topicId = topic?.id ?? null;
  }

  const { data: question, error: qError } = await supabase
    .from("questions")
    .insert({
      subject_id: subject.id,
      topic_id: topicId,
      question_text: row.question,
      image_url: row.image_url || null,
      explanation: row.explanation || null,
      difficulty: row.difficulty || "medium",
      tags: row.tags ? String(row.tags).split(";").map((t: string) => t.trim()) : [],
      created_by: adminId,
    })
    .select()
    .single();

  if (qError || !question) throw new Error(qError?.message ?? "Error al insertar la pregunta.");

  const correctIndex = Number(row.correct_option);
  const options = [row.option_1, row.option_2, row.option_3].map((text, idx) => ({
    question_id: question.id,
    option_text: text,
    is_correct: idx + 1 === correctIndex,
    sort_order: idx,
  }));

  const { error: oError } = await supabase.from("question_options").insert(options);
  if (oError) throw new Error(oError.message);
}
