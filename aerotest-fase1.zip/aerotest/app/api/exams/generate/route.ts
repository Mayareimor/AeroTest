import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { generateExam } from "@/lib/exam-engine/generate-exam";

const bodySchema = z.object({
  mode: z.enum([
    "official",
    "free_practice",
    "incorrect_only",
    "favorites",
    "by_subject",
    "by_topic",
  ]),
  subjectId: z.string().uuid().optional(),
  topicId: z.string().uuid().optional(),
  totalQuestions: z.number().int().min(1).max(200).optional(),
  timeLimitSeconds: z.number().int().min(60).nullable().optional(),
});

export async function POST(req: NextRequest) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "No autenticado." }, { status: 401 });
  }

  const parsed = bodySchema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const exam = await generateExam({ studentId: user.id, ...parsed.data });
    return NextResponse.json({ exam }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "Error generando el examen." }, { status: 500 });
  }
}
