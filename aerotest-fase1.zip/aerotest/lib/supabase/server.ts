import { createServerComponentClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";

// Cliente de Supabase para usar en Server Components, Route Handlers
// y en la lógica del servidor (lib/exam-engine, etc).
export function createClient() {
  return createServerComponentClient({ cookies });
}
