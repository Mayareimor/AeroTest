import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

// Cliente de Supabase para usar en Client Components (formularios,
// interacciones del examen, dashboard con actualizaciones en vivo).
export function createClient() {
  return createClientComponentClient();
}
