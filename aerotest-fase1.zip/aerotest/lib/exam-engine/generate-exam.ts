import { createClient } from "@/lib/supabase/server";
import type { ExamMode, Question } from "@/types/database";

interface GenerateExamParams {
  studentId: string;
  mode: ExamMode;
  subjectId?: string;
  topicId?: string;
  totalQuestions?: number;
  timeLimitSeconds?: number | null;
}

/**
 * Baraja un arreglo in-place usando Fisher–Yates.
 * Es el mismo algoritmo tanto para el orden de las preguntas
 * como para el orden de las opciones de respuesta.
 */
function shuffle<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Selecciona el pool de preguntas según el modo de estudio elegido.
 * Cada modo arma su propia consulta:
 *  - official / by_subject / by_topic: banco general filtrado
 *  - incorrect_only: preguntas que el estudiante falló antes
 *  - favorites: preguntas marcadas como favoritas
 */
async function fetchQuestionPool(params: GenerateExamParams): Promise<Question[]> {
  const supabase = createClient();
  const { studentId, mode, subjectId, topicId } = params;

  if (mode === "incorrect_only") {
    const { data } = await supabase
      .from("exam_questions")
      .select("question_id, questions(*, question_options(*))")
      .eq("is_correct", false)
      .eq("exams.student_id", studentId);
    return dedupeById((data ?? []).map((r: any) => r.questions));
  }

  if (mode === "favorites") {
    const { data } = await supabase
      .from("favorite_questions")
      .select("question_id, questions(*, question_options(*))")
      .eq("student_id", studentId);
    return dedupeById((data ?? []).map((r: any) => r.questions));
  }

  let query = supabase
    .from("questions")
    .select("*, question_options(*)")
    .eq("is_active", true);

  if (subjectId) query = query.eq("subject_id", subjectId);
  if (topicId) query = query.eq("topic_id", topicId);

  const { data } = await query;
  return data ?? [];
}

function dedupeById(items: Question[]): Question[] {
  const seen = new Set<string>();
  return items.filter((q) => {
    if (!q || seen.has(q.id)) return false;
    seen.add(q.id);
    return true;
  });
}

/**
 * Crea un examen nuevo:
 * 1. Trae el pool de preguntas elegible según el modo.
 * 2. Baraja y recorta a `totalQuestions`.
 * 3. Para cada pregunta, baraja el orden de sus opciones.
 * 4. Inserta el examen y sus `exam_questions` en Supabase.
 */
export async function generateExam(params: GenerateExamParams) {
  const supabase = createClient();
  const totalQuestions = params.totalQuestions ?? 50;

  const pool = await fetchQuestionPool(params);
  if (pool.length === 0) {
    throw new Error("No hay preguntas disponibles para los filtros seleccionados.");
  }

  const selected = shuffle(pool).slice(0, Math.min(totalQuestions, pool.length));

  const { data: exam, error: examError } = await supabase
    .from("exams")
    .insert({
      student_id: params.studentId,
      mode: params.mode,
      subject_id: params.subjectId ?? null,
      topic_id: params.topicId ?? null,
      total_questions: selected.length,
      time_limit_seconds: params.timeLimitSeconds ?? null,
      status: "in_progress",
    })
    .select()
    .single();

  if (examError || !exam) throw examError;

  const examQuestions = selected.map((question, index) => ({
    exam_id: exam.id,
    question_id: question.id,
    position: index,
    shuffled_option_ids: shuffle((question.options ?? []).map((o) => o.id)),
  }));

  const { error: eqError } = await supabase.from("exam_questions").insert(examQuestions);
  if (eqError) throw eqError;

  return exam;
}

/**
 * Cierra un examen: calcula calificación, correctas/incorrectas y tiempo usado.
 */
export async function finishExam(examId: string, timeUsedSeconds: number) {
  const supabase = createClient();

  const { data: examQuestions } = await supabase
    .from("exam_questions")
    .select("is_correct")
    .eq("exam_id", examId);

  const total = examQuestions?.length ?? 0;
  const correct = examQuestions?.filter((q) => q.is_correct).length ?? 0;
  const incorrect = total - correct;
  const score = total > 0 ? Math.round((correct / total) * 10000) / 100 : 0;

  const { data, error } = await supabase
    .from("exams")
    .update({
      status: "completed",
      score,
      correct_count: correct,
      incorrect_count: incorrect,
      time_used_seconds: timeUsedSeconds,
      finished_at: new Date().toISOString(),
    })
    .eq("id", examId)
    .select()
    .single();

  if (error) throw error;
  return data;
}
