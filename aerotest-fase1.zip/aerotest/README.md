# AeroTest — Plataforma de Test Kit para estudiantes de aviación

## Stack elegido (y por qué)

- **Next.js 14 (App Router) + TypeScript** — Server Components para el dashboard y
  las páginas de examen (datos siempre frescos, sin exponer lógica sensible al
  cliente) y Client Components solo donde hay interacción en vivo (temporizador,
  navegación entre preguntas).
- **Tailwind CSS** — sistema de diseño con tokens propios de AeroTest (ver
  `tailwind.config.ts`): azul marino, acero, blanco nube y ámbar aeronáutico.
- **Supabase** en lugar de Firebase — porque el banco de preguntas es
  relacional por naturaleza (materia → tema → pregunta → opciones → intentos)
  y Postgres con Row Level Security te da consultas SQL reales, filtros
  combinados y políticas de seguridad declarativas sin escribir un backend
  aparte. Firebase (NoSQL) obligaría a duplicar datos y complicaría las
  estadísticas por materia/tema.
- **Vercel** para desplegar el frontend (integración nativa con Next.js).

## Estructura del proyecto

```
app/
  (auth)/login, (auth)/register     → páginas de autenticación
  dashboard/                        → panel del estudiante
  exam/[examId]/                    → interfaz de examen en curso
  admin/questions/                  → panel de administrador (CRUD + import)
  api/exams/generate/               → genera un examen (motor de aleatorización)
  api/questions/import/             → importación masiva CSV/Excel
components/
  ui/, exam/, dashboard/            → componentes reutilizables
lib/
  supabase/                         → clientes de Supabase (server y browser)
  exam-engine/                      → lógica pura: generar y calificar exámenes
types/
  database.ts                       → tipos que reflejan el esquema SQL
supabase/migrations/0001_init.sql   → esquema completo de base de datos
```

## Lo que ya está construido (Fase 1)

1. **Esquema de base de datos completo** (`supabase/migrations/0001_init.sql`):
   perfiles, materias, temas, preguntas, opciones, exámenes, preguntas-de-examen
   (con snapshot de orden barajado), favoritos, insignias, racha de estudio y
   una vista de ranking — todo con Row Level Security activado.
2. **Motor de exámenes** (`lib/exam-engine/generate-exam.ts`): arma el pool de
   preguntas según el modo elegido (oficial, libre, solo incorrectas,
   favoritas, por materia, por tema), baraja preguntas y opciones con
   Fisher–Yates, crea el examen y lo califica al finalizar.
3. **Endpoint de generación de examen** (`app/api/exams/generate`).
4. **Endpoint de importación de preguntas** (`app/api/questions/import`):
   acepta CSV o Excel con las columnas `subject, topic, question, image_url,
   option_1, option_2, option_3, correct_option, explanation, difficulty, tags`.
5. **Identidad visual** definida y aplicada (ver la vista previa de la
   página de inicio) — el elemento distintivo es un horizonte artificial
   animado como el de un panel de vuelo (PFD), usado como pieza central del
   hero.

## Próximas fases (según lo vayamos construyendo)

- **Fase 2** — Autenticación completa (login, registro, recuperación de
  contraseña) + layout general + página de inicio real en código Next.js.
- **Fase 3** — Dashboard del estudiante con gráficos (Recharts): promedio,
  tiempo estudiado, rendimiento por materia/tema.
- **Fase 4** — Interfaz de examen: temporizador, barra de progreso,
  navegación, marcar para revisar, pantalla de resultados con explicación
  por pregunta.
- **Fase 5** — Panel de administrador: CRUD visual de preguntas, importación
  con vista previa de errores, filtros y búsqueda.
- **Fase 6** — Extras: modo oscuro/claro, insignias, rachas, ranking,
  animaciones y sonidos sutiles.

## Cómo continuar

1. Crea un proyecto en [supabase.com](https://supabase.com), corre la
   migración `supabase/migrations/0001_init.sql` en el SQL Editor.
2. Copia `.env.example` a `.env.local` y completa tus llaves.
3. `npm install && npm run dev`.
4. Cuando tengas tus preguntas del Test Kit, arma un CSV con las columnas de
   arriba y súbelo desde `/admin/questions` (Fase 5) — o dímelo aquí y te
   ayudo a prepararlo.
